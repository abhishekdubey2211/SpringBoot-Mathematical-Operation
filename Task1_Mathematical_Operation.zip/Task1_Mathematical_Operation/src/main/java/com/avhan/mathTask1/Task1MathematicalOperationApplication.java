package com.avhan.mathTask1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task1MathematicalOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(Task1MathematicalOperationApplication.class, args);
		System.out.println("Mathematical Operational Application is running sucessfully...............");
	}

}
